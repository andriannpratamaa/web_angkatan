<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('cash_payments', function (Blueprint $table) {
            $table->string('payment_method')->default('manual')->after('status');
            $table->string('reference')->nullable()->after('payment_method');
        });
    }

    public function down(): void
    {
        Schema::table('cash_payments', function (Blueprint $table) {
            $table->dropColumn(['payment_method', 'reference']);
        });
    }
};
